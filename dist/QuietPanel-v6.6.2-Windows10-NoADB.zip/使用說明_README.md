# QuietPanel v6.6.2 使用說明／Instructions

## 中文

這是**不內含第三方 ADB 二進位檔**的版本。為避免重新散布 Android SDK Platform-Tools 的授權疑慮，請使用者自行從 Google 官方來源下載 Windows Platform-Tools。

### 準備 ADB

1. 開啟官方頁面：<https://developer.android.com/tools/releases/platform-tools>
2. 下載 Windows Platform-Tools，閱讀並接受 Google Android SDK License。
3. 解壓縮後，把以下三個檔案複製到本資料夾：

```text
adb.exe
AdbWinApi.dll
AdbWinUsbApi.dll
```

### 使用 QuietPanel

1. 手機開啟「開發人員選項」與「USB 偵錯」。
2. USB 連接手機與 Windows 10 電腦。
3. 第一次連接時，在手機允許這台可信任的電腦。
4. 第一次使用或更新 App，執行 `Install-Android.cmd`。
5. 之後執行 `Start-QuietPanel.cmd` 啟動 PC Bridge。

手機 App 需要保持已安裝；Bridge 會使用本資料夾內的 `adb.exe`，搜尋唯一一台 Android 裝置並建立連線。不要直接執行 `adb.exe`。

### 頁面

系統、儲存、相簿時鐘、NASA、Macro 與快捷共六頁。第三頁點一下可進入相簿設定，調整圖片資料夾、時鐘位置、半透明底板與照片停留秒數。

### 安全與隱私

QuietPanel 使用 USB／ADB localhost Forward，不開放區域網路控制埠，也不收集照片或系統資料。USB 偵錯具有高權限，只應在自己的電腦上按「允許」。

## English

This is the **No-ADB distribution**. It does not include third-party ADB binaries. To avoid redistributing Android SDK Platform-Tools, download the Windows Platform-Tools directly from Google:

<https://developer.android.com/tools/releases/platform-tools>

Read and accept the Google Android SDK License, extract the package, and copy these files into this folder:

```text
adb.exe
AdbWinApi.dll
AdbWinUsbApi.dll
```

Then enable Developer Options and USB debugging on the phone, connect it by USB, authorize the trusted PC on the phone, run `Install-Android.cmd` once, and run `Start-QuietPanel.cmd` for daily use.

The app provides six pages: System, Storage, Photo Clock, NASA, Macro, and Shortcuts. Tap the third page to open photo settings for folders, clock position, the translucent background, and photo duration.

QuietPanel uses USB/ADB localhost forwarding and does not collect or upload photos or system data. USB debugging grants powerful access, so authorize only your own trusted computer.
